package com.investtrack.ui.loan

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.investtrack.data.database.entities.*
import com.investtrack.data.repository.*
import com.investtrack.utils.FinancialUtils
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class LoanSummary(
    val loan: Loan,
    val memberName: String,
    val paidInstallments: Int,
    val totalPrincipalPaid: Double,
    val totalInterestPaid: Double,
    val outstandingPrincipal: Double,
    val remainingInstallments: Int
)

@HiltViewModel
class LoanViewModel @Inject constructor(
    private val loanRepo: LoanRepository,
    private val familyRepo: FamilyRepository
) : ViewModel() {
    val allLoans = loanRepo.getAllLoans().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allMembers = familyRepo.getAllMembers().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun getPayments(loanId: Long) = loanRepo.getPayments(loanId)

    suspend fun buildLoanSummary(loan: Loan): LoanSummary {
        val paid = loanRepo.getPaidInstallments(loan.id)
        val principalPaid = loanRepo.getTotalPrincipalPaid(loan.id)
        val interestPaid = loanRepo.getTotalInterestPaid(loan.id)
        val outstanding = (loan.loanAmount - principalPaid).coerceAtLeast(0.0)
        val remaining = (loan.tenureMonths - paid).coerceAtLeast(0)
        val member = allMembers.value.find { it.id == loan.familyMemberId }
        return LoanSummary(loan, member?.name ?: "Unknown", paid, principalPaid, interestPaid, outstanding, remaining)
    }

    fun saveLoan(loan: Loan, onDone: () -> Unit) {
        viewModelScope.launch {
            if (loan.id == 0L) loanRepo.insertLoan(loan) else loanRepo.updateLoan(loan)
            onDone()
        }
    }

    fun deleteLoan(id: Long) = viewModelScope.launch { loanRepo.deleteLoan(id) }

    fun markEMIPaid(loan: Loan, installmentNumber: Int, schedule: List<FinancialUtils.AmortisationRow>, onDone: () -> Unit) {
        viewModelScope.launch {
            val row = schedule.getOrNull(installmentNumber - 1) ?: return@launch
            loanRepo.insertPayment(LoanPayment(
                loanId = loan.id, paymentDate = System.currentTimeMillis(),
                installmentNumber = installmentNumber, emiPaid = row.emi,
                principalPaid = row.principal, interestPaid = row.interest, outstandingBalance = row.balance
            ))
            onDone()
        }
    }

    suspend fun getLoan(id: Long) = loanRepo.getLoanById(id)
}

// ─────────────────────────────────────────────────────────
// Loan List Screen
// ─────────────────────────────────────────────────────────

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.investtrack.ui.common.*
import com.investtrack.ui.theme.LossColor
import com.investtrack.utils.FinancialUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoanListScreen(onAddLoan: () -> Unit, onLoanDetail: (Long) -> Unit, onBack: () -> Unit, vm: LoanViewModel = hiltViewModel()) {
    val loans by vm.allLoans.collectAsState()

    var loanSummaries by remember { mutableStateOf(listOf<LoanSummary>()) }
    LaunchedEffect(loans) {
        loanSummaries = loans.map { vm.buildLoanSummary(it) }
    }

    val totalOutstanding = loanSummaries.sumOf { it.outstandingPrincipal }
    val totalEMI = loans.sumOf { it.emiAmount }

    Scaffold(
        topBar = { TopBarWithBack("Loans", onBack) }
    ) { padding ->
        LazyColumn(contentPadding = PaddingValues(16.dp), modifier = Modifier.fillMaxSize().padding(padding), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (loans.isNotEmpty()) {
                item {
                    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = LossColor.copy(0.1f))) {
                        Row(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("Total Outstanding", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(FinancialUtils.formatCurrency(totalOutstanding), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = LossColor)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Total Monthly EMI", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(FinancialUtils.formatCurrency(totalEMI), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
            if (loanSummaries.isEmpty()) {
                item { EmptyState("No loans added. Tap + to add one.") }
            }
            items(loanSummaries) { summary ->
                LoanCard(summary, onClick = { onLoanDetail(summary.loan.id) }, onDelete = { vm.deleteLoan(summary.loan.id) })
            }
        }
    }
}

@Composable
fun LoanCard(summary: LoanSummary, onClick: () -> Unit, onDelete: () -> Unit) {
    val loan = summary.loan
    val progress = (loan.loanAmount - summary.outstandingPrincipal) / loan.loanAmount

    Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth(), onClick = onClick) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AccountBalance, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(loan.loanName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text("${loan.loanType.name.replace("_", " ")} • ${summary.memberName}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error) }
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("Outstanding", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(FinancialUtils.formatCurrency(summary.outstandingPrincipal), fontWeight = FontWeight.Bold, color = LossColor)
                }
                Column {
                    Text("EMI", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(FinancialUtils.formatCurrency(loan.emiAmount), fontWeight = FontWeight.Bold)
                }
                Column {
                    Text("Rate", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${loan.interestRate}%", fontWeight = FontWeight.Bold)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Remaining", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${summary.remainingInstallments} EMIs", fontWeight = FontWeight.Bold)
                }
            }
            LinearProgressIndicator(progress = { progress.toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(6.dp), color = MaterialTheme.colorScheme.primary)
            Text("${(progress * 100).toInt()}% repaid", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ─────────────────────────────────────────────────────────
// Add/Edit Loan Screen
// ─────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditLoanScreen(loanId: Long?, onBack: () -> Unit, vm: LoanViewModel = hiltViewModel()) {
    val members by vm.allMembers.collectAsState()
    var selectedMember by remember { mutableStateOf<FamilyMember?>(null) }
    var loanName by remember { mutableStateOf("") }
    var loanType by remember { mutableStateOf(LoanType.HOME_LOAN) }
    var lenderName by remember { mutableStateOf("") }
    var accountNumber by remember { mutableStateOf("") }
    var loanAmount by remember { mutableStateOf("") }
    var interestRate by remember { mutableStateOf("") }
    var tenureMonths by remember { mutableStateOf("") }
    var disbursementDate by remember { mutableStateOf(System.currentTimeMillis()) }
    var processingFee by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    // Computed EMI
    val computedEMI = remember(loanAmount, interestRate, tenureMonths) {
        val p = loanAmount.toDoubleOrNull() ?: 0.0
        val r = interestRate.toDoubleOrNull() ?: 0.0
        val n = tenureMonths.toIntOrNull() ?: 0
        if (p > 0 && r > 0 && n > 0) FinancialUtils.calculateEMI(p, r, n) else 0.0
    }
    var emiAmount by remember { mutableStateOf("") }
    LaunchedEffect(computedEMI) { if (computedEMI > 0 && emiAmount.isBlank()) emiAmount = "%.2f".format(computedEMI) }

    LaunchedEffect(loanId) {
        if (members.isNotEmpty()) selectedMember = members.first()
        loanId?.let { id ->
            vm.getLoan(id)?.let { l ->
                loanName = l.loanName; loanType = l.loanType; lenderName = l.lenderName
                accountNumber = l.accountNumber; loanAmount = l.loanAmount.toString()
                interestRate = l.interestRate.toString(); tenureMonths = l.tenureMonths.toString()
                disbursementDate = l.disbursementDate; processingFee = l.processingFee.toString()
                emiAmount = l.emiAmount.toString(); notes = l.notes
                selectedMember = members.find { it.id == l.familyMemberId }
            }
        }
    }
    LaunchedEffect(members) { if (selectedMember == null && members.isNotEmpty()) selectedMember = members.first() }

    Scaffold(
        topBar = { TopBarWithBack(if (loanId != null) "Edit Loan" else "Add Loan", onBack) },
        bottomBar = {
            Surface(shadowElevation = 8.dp) {
                Button(
                    onClick = {
                        val loan = Loan(
                            id = loanId ?: 0L, familyMemberId = selectedMember!!.id, loanName = loanName,
                            loanType = loanType, lenderName = lenderName, accountNumber = accountNumber,
                            loanAmount = loanAmount.toDoubleOrNull() ?: 0.0, interestRate = interestRate.toDoubleOrNull() ?: 0.0,
                            tenureMonths = tenureMonths.toIntOrNull() ?: 0, disbursementDate = disbursementDate,
                            emiAmount = emiAmount.toDoubleOrNull() ?: computedEMI, processingFee = processingFee.toDoubleOrNull() ?: 0.0, notes = notes
                        )
                        vm.saveLoan(loan) { onBack() }
                    },
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    enabled = selectedMember != null && loanName.isNotBlank() && loanAmount.isNotBlank() && interestRate.isNotBlank() && tenureMonths.isNotBlank(),
                    shape = RoundedCornerShape(12.dp)
                ) { Text(if (loanId != null) "Update Loan" else "Save Loan") }
            }
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Loan Details", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        DropdownField("Family Member *", members, selectedMember, { selectedMember = it }, { it.name })
                        InputField("Loan Name *", loanName, { loanName = it })
                        DropdownField("Loan Type *", LoanType.values().toList(), loanType, { loanType = it }, { it.name.replace("_", " ") })
                        InputField("Lender Name", lenderName, { lenderName = it })
                        InputField("Account / Loan Number", accountNumber, { accountNumber = it })
                        DateField("Disbursement Date *", disbursementDate, { disbursementDate = it })
                    }
                }
            }
            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Loan Parameters", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        InputField("Loan Amount (₹) *", loanAmount, { loanAmount = it; emiAmount = "" }, keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal)
                        InputField("Interest Rate (% p.a.) *", interestRate, { interestRate = it; emiAmount = "" }, keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal)
                        InputField("Tenure (Months) *", tenureMonths, { tenureMonths = it; emiAmount = "" }, keyboardType = androidx.compose.ui.text.input.KeyboardType.Number)

                        if (computedEMI > 0) {
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), shape = RoundedCornerShape(12.dp)) {
                                Row(modifier = Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Column {
                                        Text("Computed EMI", style = MaterialTheme.typography.labelMedium)
                                        Text(FinancialUtils.formatCurrencyFull(computedEMI), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    }
                                    Column {
                                        Text("Total Interest", style = MaterialTheme.typography.labelMedium)
                                        val months = tenureMonths.toIntOrNull() ?: 0
                                        Text(FinancialUtils.formatCurrency(computedEMI * months - (loanAmount.toDoubleOrNull() ?: 0.0)), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = LossColor)
                                    }
                                }
                            }
                        }
                        InputField("Actual EMI (editable) *", emiAmount, { emiAmount = it }, keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal)
                        InputField("Processing Fee (₹)", processingFee, { processingFee = it }, keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal)
                        InputField("Notes", notes, { notes = it })
                    }
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────
// Loan Detail Screen (Amortisation + EMI marking)
// ─────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoanDetailScreen(loanId: Long, onEdit: (Long) -> Unit, onBack: () -> Unit, vm: LoanViewModel = hiltViewModel()) {
    var loan by remember { mutableStateOf<Loan?>(null) }
    var summary by remember { mutableStateOf<LoanSummary?>(null) }
    var schedule by remember { mutableStateOf(listOf<FinancialUtils.AmortisationRow>()) }
    var refreshKey by remember { mutableStateOf(0) }

    LaunchedEffect(loanId, refreshKey) {
        loan = vm.getLoan(loanId)
        loan?.let { l ->
            summary = vm.buildLoanSummary(l)
            schedule = FinancialUtils.generateAmortisationSchedule(l.loanAmount, l.interestRate, l.tenureMonths, l.emiAmount)
        }
    }

    val payments by (loan?.let { vm.getPayments(it.id) } ?: flowOf(emptyList())).collectAsState(initial = emptyList())
    val paidInstallments = payments.map { it.installmentNumber }.toSet()

    Scaffold(
        topBar = { TopBarWithBack("Loan Detail", onBack) { IconButton(onClick = { onEdit(loanId) }) { Icon(Icons.Default.Edit, "Edit") } } }
    ) { padding ->
        loan?.let { l ->
            LazyColumn(modifier = Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                item {
                    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(l.loanName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("${l.loanType.name.replace("_", " ")} • ${l.lenderName}".trim(' ', '•'), style = MaterialTheme.typography.bodySmall)
                            HorizontalDivider()
                            summary?.let { s ->
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    LoanDetailItem("Loan Amount", FinancialUtils.formatCurrency(l.loanAmount))
                                    LoanDetailItem("Outstanding", FinancialUtils.formatCurrency(s.outstandingPrincipal), LossColor)
                                    LoanDetailItem("EMI", FinancialUtils.formatCurrency(l.emiAmount))
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    LoanDetailItem("Rate", "${l.interestRate}% p.a.")
                                    LoanDetailItem("Paid EMIs", "${s.paidInstallments}/${l.tenureMonths}")
                                    LoanDetailItem("Remaining", "${s.remainingInstallments} EMIs")
                                }
                                val progress = (l.loanAmount - s.outstandingPrincipal) / l.loanAmount
                                LinearProgressIndicator(progress = { progress.toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(8.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Interest Paid: ${FinancialUtils.formatCurrency(s.totalInterestPaid)}", style = MaterialTheme.typography.labelSmall, color = LossColor)
                                    Text("Principal Paid: ${FinancialUtils.formatCurrency(s.totalPrincipalPaid)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
                item { SectionHeader("Amortisation Schedule") }
                items(schedule) { row ->
                    val isPaid = row.installment in paidInstallments
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = if (isPaid) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface)
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("#${row.installment}", style = MaterialTheme.typography.labelLarge, modifier = Modifier.width(32.dp), fontWeight = FontWeight.Bold)
                            Column(modifier = Modifier.weight(1f)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text("P: ${FinancialUtils.formatCurrency(row.principal)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                                    Text("I: ${FinancialUtils.formatCurrency(row.interest)}", style = MaterialTheme.typography.bodySmall, color = LossColor)
                                }
                                Text("Balance: ${FinancialUtils.formatCurrency(row.balance)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(FinancialUtils.formatCurrency(row.emi), fontWeight = FontWeight.Bold)
                            if (!isPaid) {
                                Spacer(Modifier.width(8.dp))
                                OutlinedButton(onClick = {
                                    vm.markEMIPaid(l, row.installment, schedule) { refreshKey++ }
                                }, modifier = Modifier.height(32.dp), contentPadding = PaddingValues(horizontal = 8.dp)) {
                                    Text("Pay", style = MaterialTheme.typography.labelSmall)
                                }
                            } else {
                                Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }
            }
        } ?: Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    }
}

@Composable
fun LoanDetailItem(label: String, value: String, valueColor: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurface) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = valueColor)
    }
}

import androidx.compose.ui.graphics.Color
import com.investtrack.data.database.entities.*
import kotlinx.coroutines.flow.flowOf
