package com.investtrack.ui.price

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.investtrack.data.database.entities.*
import com.investtrack.data.repository.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PriceViewModel @Inject constructor(
    private val priceRepo: PriceRepository,
    private val securityRepo: SecurityRepository
) : ViewModel() {
    val allSecurities = securityRepo.getAllSecurities().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun getPriceHistory(securityId: Long) = priceRepo.getPriceHistory(securityId)

    suspend fun getSecurity(id: Long) = securityRepo.getSecurityById(id)
    suspend fun searchSecurities(q: String) = securityRepo.searchSecurities(q)

    fun savePrice(securityId: Long, date: Long, price: Double, onDone: () -> Unit) {
        viewModelScope.launch {
            priceRepo.insertPrice(PriceHistory(securityId = securityId, priceDate = date, price = price))
            onDone()
        }
    }
    fun deletePrice(securityId: Long, date: Long) = viewModelScope.launch { priceRepo.deletePrice(securityId, date) }
}

// ─────────────────────────────────────────────────────────
// Price Update Screen
// ─────────────────────────────────────────────────────────

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.investtrack.ui.common.*
import com.investtrack.utils.DateUtils.toDisplayDate
import com.investtrack.utils.FinancialUtils
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PriceUpdateScreen(preSelectedSecurityId: Long?, onBack: () -> Unit, vm: PriceViewModel = hiltViewModel()) {
    val scope = rememberCoroutineScope()
    var selectedSecurity by remember { mutableStateOf<SecurityMaster?>(null) }
    var securityQuery by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf(listOf<SecurityMaster>()) }
    var showSearch by remember { mutableStateOf(false) }
    var priceDate by remember { mutableStateOf(System.currentTimeMillis()) }
    var priceValue by remember { mutableStateOf("") }
    var showSuccess by remember { mutableStateOf(false) }

    LaunchedEffect(preSelectedSecurityId) {
        preSelectedSecurityId?.let { id ->
            selectedSecurity = vm.getSecurity(id)
            selectedSecurity?.let { securityQuery = it.securityName }
        }
    }

    val priceHistory = selectedSecurity?.let { vm.getPriceHistory(it.id).collectAsState(initial = emptyList()) }

    Scaffold(
        topBar = { TopBarWithBack("Update Price / NAV", onBack) }
    ) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Add / Update Price", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = securityQuery,
                            onValueChange = { q ->
                                securityQuery = q; showSearch = true
                                scope.launch { searchResults = vm.searchSecurities(q) }
                            },
                            label = { Text("Search Security") },
                            trailingIcon = { Icon(Icons.Default.Search, null) },
                            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), singleLine = true
                        )
                        if (showSearch && searchResults.isNotEmpty()) {
                            Card(elevation = CardDefaults.cardElevation(8.dp)) {
                                searchResults.take(5).forEach { sec ->
                                    ListItem(headlineContent = { Text(sec.securityName) }, supportingContent = { Text(sec.securityCode) },
                                        modifier = Modifier.clickable { selectedSecurity = sec; securityQuery = sec.securityName; showSearch = false })
                                    HorizontalDivider()
                                }
                            }
                        }
                        DateField("Price Date *", priceDate, { priceDate = it })
                        InputField(
                            "Price / NAV (₹) *", priceValue, { priceValue = it },
                            keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal
                        )
                        if (showSuccess) {
                            Text("✅ Price saved successfully!", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                        }
                        Button(
                            onClick = {
                                val sec = selectedSecurity ?: return@Button
                                val p = priceValue.toDoubleOrNull() ?: return@Button
                                vm.savePrice(sec.id, priceDate, p) { showSuccess = true; priceValue = "" }
                            },
                            enabled = selectedSecurity != null && priceValue.isNotBlank(),
                            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)
                        ) { Text("Save Price") }
                    }
                }
            }

            if (priceHistory != null) {
                val history = priceHistory.value
                if (history.isNotEmpty()) {
                    item {
                        SectionHeader("Price History for ${selectedSecurity?.securityName ?: ""}")
                    }
                    items(history.take(20)) { ph ->
                        Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(ph.priceDate.toDisplayDate(), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                    Text("Source: ${ph.source}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text("₹${"%.4f".format(ph.price)}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                IconButton(onClick = { vm.deletePrice(ph.securityId, ph.priceDate) }) {
                                    Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

import androidx.compose.foundation.clickable
