package com.investtrack.ui.transaction

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.investtrack.data.database.entities.*
import com.investtrack.data.repository.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class TransactionViewModel @Inject constructor(
    private val transactionRepo: TransactionRepository,
    private val securityRepo: SecurityRepository,
    private val familyRepo: FamilyRepository
) : ViewModel() {
    val allTransactions = transactionRepo.getAllTransactions().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val recentTransactions = transactionRepo.getRecentTransactions(20).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allMembers = familyRepo.getAllMembers().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    suspend fun searchSecurities(query: String) = securityRepo.searchSecurities(query)
    suspend fun getSecurity(id: Long) = securityRepo.getSecurityById(id)

    fun saveTransaction(t: Transaction, onDone: () -> Unit) {
        viewModelScope.launch {
            if (t.id == 0L) transactionRepo.insert(t) else transactionRepo.update(t)
            onDone()
        }
    }
    fun deleteTransaction(t: Transaction) = viewModelScope.launch { transactionRepo.delete(t) }
}

// ─────────────────────────────────────────────────────────
// Transaction List Screen
// ─────────────────────────────────────────────────────────

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.investtrack.ui.common.*
import com.investtrack.ui.theme.GainColor
import com.investtrack.ui.theme.LossColor
import com.investtrack.utils.DateUtils.toDisplayDate
import com.investtrack.utils.FinancialUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransactionListScreen(onAddTransaction: () -> Unit, onBack: () -> Unit, vm: TransactionViewModel = hiltViewModel()) {
    val transactions by vm.allTransactions.collectAsState()
    val members by vm.allMembers.collectAsState()

    Scaffold(
        topBar = { TopBarWithBack("Transactions", onBack) }
    ) { padding ->
        LazyColumn(contentPadding = PaddingValues(16.dp), modifier = Modifier.fillMaxSize().padding(padding), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (transactions.isEmpty()) {
                item { EmptyState("No transactions yet. Tap + to add one.") }
            }
            items(transactions) { txn ->
                var secName by remember { mutableStateOf("") }
                var memberName by remember { mutableStateOf("") }
                LaunchedEffect(txn.id) {
                    secName = vm.getSecurity(txn.securityId)?.securityName ?: "Unknown"
                    memberName = members.find { it.id == txn.familyMemberId }?.name ?: "Unknown"
                }
                TransactionCard(txn, secName, memberName, onDelete = { vm.deleteTransaction(txn) })
            }
        }
    }
}

@Composable
fun TransactionCard(txn: Transaction, secName: String, memberName: String, onDelete: () -> Unit) {
    val isBuy = txn.transactionType in listOf(TransactionType.BUY, TransactionType.SIP, TransactionType.INVEST, TransactionType.DEPOSIT, TransactionType.PREMIUM)
    val amount = txn.amount ?: ((txn.units ?: 0.0) * (txn.price ?: 0.0))

    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = CircleShape, color = if (isBuy) GainColor.copy(0.15f) else LossColor.copy(0.15f), modifier = Modifier.size(40.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(if (isBuy) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward, null,
                        tint = if (isBuy) GainColor else LossColor, modifier = Modifier.size(20.dp))
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(secName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text("${txn.transactionType.name} • $memberName", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(txn.transactionDate.toDisplayDate(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    txn.units?.let { Text("${it.formatAs2Dec()} units @ ₹${txn.price?.formatAs2Dec()}", style = MaterialTheme.typography.labelSmall) }
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(FinancialUtils.formatCurrency(amount), fontWeight = FontWeight.Bold, color = if (isBuy) MaterialTheme.colorScheme.onSurface else LossColor)
            }
        }
    }
}

// ─────────────────────────────────────────────────────────
// Add Transaction Screen
// ─────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTransactionScreen(preSelectedSecurityId: Long?, onBack: () -> Unit, vm: TransactionViewModel = hiltViewModel()) {
    val members by vm.allMembers.collectAsState()

    var selectedMember by remember { mutableStateOf<FamilyMember?>(null) }
    var selectedSecurity by remember { mutableStateOf<SecurityMaster?>(null) }
    var securityQuery by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf(listOf<SecurityMaster>()) }
    var showSearch by remember { mutableStateOf(false) }

    var txnDate by remember { mutableStateOf(System.currentTimeMillis()) }
    var txnType by remember { mutableStateOf(TransactionType.BUY) }
    var units by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var stampDuty by remember { mutableStateOf("") }
    var brokerage by remember { mutableStateOf("") }
    var stt by remember { mutableStateOf("") }
    var folioNumber by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    // Pre-select security
    LaunchedEffect(preSelectedSecurityId) {
        preSelectedSecurityId?.let { id ->
            selectedSecurity = vm.getSecurity(id)
            selectedSecurity?.let { securityQuery = it.securityName }
        }
    }
    // Auto-select first member
    LaunchedEffect(members) {
        if (selectedMember == null && members.isNotEmpty()) selectedMember = members.first()
    }

    val isUnitBased = selectedSecurity?.let {
        it.securityType in listOf(SecurityType.MUTUAL_FUND, SecurityType.SHARES, SecurityType.BOND, SecurityType.GOI_BOND)
    } ?: true

    val validTxnTypes = selectedSecurity?.let { sec ->
        when (sec.securityType) {
            SecurityType.MUTUAL_FUND -> listOf(TransactionType.BUY, TransactionType.SELL, TransactionType.SIP, TransactionType.SWP, TransactionType.DIVIDEND)
            SecurityType.SHARES -> listOf(TransactionType.BUY, TransactionType.SELL, TransactionType.BONUS, TransactionType.DIVIDEND)
            SecurityType.BOND, SecurityType.GOI_BOND -> listOf(TransactionType.BUY, TransactionType.SELL, TransactionType.COUPON, TransactionType.MATURITY)
            SecurityType.NPS -> listOf(TransactionType.INVEST, TransactionType.REDEEM)
            SecurityType.PF -> listOf(TransactionType.INVEST, TransactionType.REDEEM, TransactionType.INTEREST)
            SecurityType.FD -> listOf(TransactionType.DEPOSIT, TransactionType.WITHDRAWAL, TransactionType.MATURITY, TransactionType.INTEREST)
            SecurityType.INSURANCE -> listOf(TransactionType.PREMIUM, TransactionType.MATURITY)
            SecurityType.PROPERTY -> listOf(TransactionType.BUY, TransactionType.SELL)
            else -> TransactionType.values().toList()
        }
    } ?: TransactionType.values().toList()

    // Auto amount calc
    val calcAmount = if (isUnitBased && units.isNotBlank() && price.isNotBlank()) {
        ((units.toDoubleOrNull() ?: 0.0) * (price.toDoubleOrNull() ?: 0.0)).toString()
    } else amount

    val canSave = selectedMember != null && selectedSecurity != null && txnDate > 0 &&
            (if (isUnitBased) units.isNotBlank() && price.isNotBlank() else amount.isNotBlank())

    Scaffold(
        topBar = { TopBarWithBack("Add Transaction", onBack) },
        bottomBar = {
            Surface(shadowElevation = 8.dp) {
                Button(
                    onClick = {
                        val t = Transaction(
                            familyMemberId = selectedMember!!.id,
                            securityId = selectedSecurity!!.id,
                            transactionDate = txnDate,
                            transactionType = txnType,
                            units = units.toDoubleOrNull(),
                            price = price.toDoubleOrNull(),
                            amount = calcAmount.toDoubleOrNull(),
                            stampDuty = stampDuty.toDoubleOrNull() ?: 0.0,
                            brokerage = brokerage.toDoubleOrNull() ?: 0.0,
                            stt = stt.toDoubleOrNull() ?: 0.0,
                            folioNumber = folioNumber,
                            notes = notes
                        )
                        vm.saveTransaction(t) { onBack() }
                    },
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    enabled = canSave,
                    shape = RoundedCornerShape(12.dp)
                ) { Text("Save Transaction") }
            }
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Transaction Details", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                        // Family Member selector
                        DropdownField("Family Member *", members, selectedMember, { selectedMember = it }, { it.name })

                        // Security search
                        OutlinedTextField(
                            value = securityQuery,
                            onValueChange = { q ->
                                securityQuery = q
                                viewModelScope.launch { searchResults = vm.searchSecurities(q) }
                                showSearch = true
                            },
                            label = { Text("Search Security *") },
                            trailingIcon = { Icon(Icons.Default.Search, null) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )
                        if (showSearch && searchResults.isNotEmpty()) {
                            Card(shape = RoundedCornerShape(12.dp), elevation = CardDefaults.cardElevation(8.dp)) {
                                searchResults.take(5).forEach { sec ->
                                    ListItem(
                                        headlineContent = { Text(sec.securityName) },
                                        supportingContent = { Text(sec.securityCode) },
                                        leadingContent = { Text(sec.securityType.name.take(2)) },
                                        modifier = Modifier.clickable {
                                            selectedSecurity = sec; securityQuery = sec.securityName; showSearch = false
                                            txnType = validTxnTypes.first()
                                        }
                                    )
                                    HorizontalDivider()
                                }
                            }
                        }
                        selectedSecurity?.let { PillChip(it.securityType.name.replace("_", " "), MaterialTheme.colorScheme.primary) }

                        DropdownField("Transaction Type *", validTxnTypes, txnType, { txnType = it }, { it.name.replace("_", " ") })
                        DateField("Transaction Date *", txnDate, { txnDate = it })
                    }
                }
            }

            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Amount Details", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        if (isUnitBased) {
                            InputField("Units *", units, { units = it }, keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal)
                            InputField("Price / NAV (₹) *", price, { price = it }, keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal)
                            if (units.isNotBlank() && price.isNotBlank()) {
                                val totalAmt = (units.toDoubleOrNull() ?: 0.0) * (price.toDoubleOrNull() ?: 0.0)
                                Text("Total Amount: ${FinancialUtils.formatCurrencyFull(totalAmt)}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                            }
                        } else {
                            InputField("Amount (₹) *", amount, { amount = it }, keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal)
                        }
                        if (selectedSecurity?.securityType in listOf(SecurityType.MUTUAL_FUND, SecurityType.SHARES)) {
                            InputField("Folio / DP No.", folioNumber, { folioNumber = it })
                        }
                    }
                }
            }

            if (isUnitBased && selectedSecurity?.securityType in listOf(SecurityType.SHARES, SecurityType.BOND)) {
                item {
                    Card(shape = RoundedCornerShape(16.dp)) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("Charges (Optional)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                InputField("Brokerage (₹)", brokerage, { brokerage = it }, modifier = Modifier.weight(1f), keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal)
                                InputField("STT (₹)", stt, { stt = it }, modifier = Modifier.weight(1f), keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal)
                            }
                            InputField("Stamp Duty (₹)", stampDuty, { stampDuty = it }, keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal)
                        }
                    }
                }
            }

            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        InputField("Notes (Optional)", notes, { notes = it })
                    }
                }
            }
        }
    }
}

private fun Double.formatAs2Dec() = "%.4f".format(this)
// need viewModelScope in composable context
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch as viewModelLaunch
